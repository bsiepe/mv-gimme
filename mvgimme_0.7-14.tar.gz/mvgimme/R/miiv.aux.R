
#' @keywords internal
getModelList = getFromNamespace("getModelList", "MIIVsem")

#' @keywords internal
factorScores = getFromNamespace("factorScores", "MIIVsem")

#' @keywords internal
fitFinalGimmeModels = getFromNamespace("fitFinalGimmeModels", "MIIVsem")